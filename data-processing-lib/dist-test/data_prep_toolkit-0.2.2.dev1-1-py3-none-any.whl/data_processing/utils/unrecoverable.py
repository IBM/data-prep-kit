class UnrecoverableException(Exception):
    """
    Raised when a transform wants to cancel overall execution
    Default - skip this file and continue
    """

    pass
